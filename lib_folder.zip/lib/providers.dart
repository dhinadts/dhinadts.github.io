import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// Theme provider
final themeProvider = StateProvider<ThemeMode>((ref) => ThemeMode.light);

// Simple resume data provider (could be extended to fetch from file)
final resumeProvider = Provider<Resume>((ref) {
  return Resume(
    name: 'DHINAKARAN KALAIMANI',
    location: 'Tiruchengode, Tamil Nadu',
    phone: '+91 96770 96359',
    email: 'dhinadts@gmail.com',
    title: 'Flutter Developer',
    summary: 'Flutter Developer with 4+ years of experience in building scalable, cross-platform apps using Flutter, Dart, and Firebase.',
    skills: [
      'Dart', 'Flutter', 'Firebase', 'Node.js', 'REST APIs', 'Git', 'Material UI'
    ],
    experiences: [
      Experience(title: 'Flutter Developer – Sivisoft Solutions Pvt. Ltd.', period: 'Jun 2021 – May 2024', details: 'Contributed to Memberly app, integrated video consultations, attendance modules, IoT data visualization.'),
      Experience(title: 'Junior Software Developer – Nithra Edu Solutions', period: 'Jun 2019 – Jul 2020', details: 'Developed iOS apps of Thirukkural, Tamil Dictionary using Flutter.'),
    ],
    projects: [
      Project(name: 'QTify', when: 'May, 25', details: 'Song-browsing app using ReactJS and Material UI.'),
      Project(name: 'XBotAI', when: 'Jun, 25', details: 'AI-powered chatbot built using ReactJS.'),
    ],
    education: [
      'M.E. – VLSI Design (2013–2015) - Anna University',
      'B.E. – Electronics & Communication (2002–2006) - Anna University'
    ],
    certifications: [
      'Full Stack Fellowship – Crio.do',
      'Flutter Internship Training – Inmakes Infotech'
    ]
  );
});

// Data classes
class Resume {
  final String name, location, phone, email, title, summary;
  final List<String> skills;
  final List<Experience> experiences;
  final List<Project> projects;
  final List<String> education;
  final List<String> certifications;

  Resume({
    required this.name,
    required this.location,
    required this.phone,
    required this.email,
    required this.title,
    required this.summary,
    required this.skills,
    required this.experiences,
    required this.projects,
    required this.education,
    required this.certifications,
  });
}

class Experience {
  final String title;
  final String period;
  final String details;
  Experience({required this.title, required this.period, required this.details});
}

class Project {
  final String name;
  final String when;
  final String details;
  Project({required this.name, required this.when, required this.details});
}
