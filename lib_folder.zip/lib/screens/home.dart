import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers.dart';
import '../widgets/header.dart';
import '../widgets/section.dart';
import '../widgets/resume_card.dart';
import '../utils/responsive.dart';

class HomeScreen extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final resume = ref.watch(resumeProvider);
    final isWide = isDisplayDesktop(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Resume - ${'${resume.name.split(' ')}'}'),
        actions: [
          IconButton(
            icon: Icon(Icons.brightness_6),
            onPressed: () {
              final theme = ref.read(themeProvider.notifier);
              theme.state = theme.state == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
            },
          )
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: isWide ? Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Flexible(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Header(resume: resume),
                  SizedBox(height: 16),
                  Section(title: 'Summary', child: Text(resume.summary)),
                  SizedBox(height: 16),
                  Section(title: 'Skills', child: Wrap(
                    spacing: 8, runSpacing: 8,
                    children: resume.skills.map((s) => Chip(label: Text(s))).toList(),
                  )),
                ],
              ),
            ),
            SizedBox(width: 24),
            Flexible(
              flex: 5,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    for (final exp in resume.experiences) ResumeCard(title: exp.title, subtitle: exp.period, content: exp.details),
                    for (final proj in resume.projects) ResumeCard(title: proj.name, subtitle: proj.when, content: proj.details),
                    ResumeCard(title: 'Education', subtitle: '', content: resume.education.join('\n')),
                    ResumeCard(title: 'Certifications', subtitle: '', content: resume.certifications.join('\n')),
                  ],
                ),
              ),
            ),
          ],
        ) : SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Header(resume: resume),
              SizedBox(height: 12),
              Section(title: 'Summary', child: Text(resume.summary)),
              SizedBox(height: 12),
              Section(title: 'Skills', child: Wrap(
                spacing: 8, runSpacing: 8,
                children: resume.skills.map((s) => Chip(label: Text(s))).toList(),
              )),
              SizedBox(height: 12),
              for (final exp in resume.experiences) ResumeCard(title: exp.title, subtitle: exp.period, content: exp.details),
              for (final proj in resume.projects) ResumeCard(title: proj.name, subtitle: proj.when, content: proj.details),
              ResumeCard(title: 'Education', subtitle: '', content: resume.education.join('\n')),
              ResumeCard(title: 'Certifications', subtitle: '', content: resume.certifications.join('\n')),
            ],
          ),
        ),
      ),
    );
  }
}
