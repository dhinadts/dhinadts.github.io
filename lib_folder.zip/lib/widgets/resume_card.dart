import 'package:flutter/material.dart';

class ResumeCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String content;

  const ResumeCard({required this.title, required this.subtitle, required this.content});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical:8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(child: Text(title, style: Theme.of(context).textTheme.subtitle1?.copyWith(fontWeight: FontWeight.w600))),
              if (subtitle.isNotEmpty) Text(subtitle, style: Theme.of(context).textTheme.caption),
            ]),
            SizedBox(height:8),
            Text(content),
          ],
        ),
      ),
    );
  }
}
