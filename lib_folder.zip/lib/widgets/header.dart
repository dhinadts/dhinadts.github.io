import 'package:flutter/material.dart';
import '../providers.dart';

class Header extends StatelessWidget {
  final Resume resume;
  const Header({required this.resume});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(radius: 36, child: Text(resume.name.split(' ').map((s)=>s[0]).take(2).join(), style: TextStyle(fontSize: 20))),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(resume.name, style: Theme.of(context).textTheme.headline6),
                  SizedBox(height: 4),
                  Text(resume.title, style: Theme.of(context).textTheme.subtitle1),
                  SizedBox(height: 8),
                  Row(children: [
                    Icon(Icons.location_on, size: 16), SizedBox(width:4), Text(resume.location),
                    SizedBox(width:12),
                    Icon(Icons.phone, size:16), SizedBox(width:4), Text(resume.phone),
                  ]),
                  SizedBox(height: 6),
                  Text(resume.email),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
